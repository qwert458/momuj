<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => '网站需要休息一下!',
    'In the system maintenance, please come again tomorrow' => '系统维护中，请明天再来',
    'Temporarily closed' => '暂时关闭'
];