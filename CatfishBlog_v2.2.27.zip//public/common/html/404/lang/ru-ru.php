<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => 'Вы посетите страницу вышел играть!',
    'The page does not exist, please click the link at the bottom of the page to return' => 'Вы посетите страницу не существует, пожалуйста, нажмите на нижней части страницы ссылки для возврата',
    'Access error' => 'Ошибка доступа',
    'Return to the home page' => 'дома'
];