<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => '당신은 페이지가 놀러 갔다 방문!',
    'The page does not exist, please click the link at the bottom of the page to return' => '당신은 존재하지 않는 페이지를 방문, 반환 페이지 링크의 맨 아래를 클릭하십시오',
    'Access error' => '액세스 오류',
    'Return to the home page' => '홈페이지로 돌아 가기'
];