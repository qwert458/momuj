<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => 'Sie besuchen die Seite zu spielen ging!',
    'The page does not exist, please click the link at the bottom of the page to return' => 'Die Seite existiert nicht, bitte klicken Sie auf den Link am unteren Rand der Seite, um zurückzukehren',
    'Access error' => 'Zugriffsfehler',
    'Return to the home page' => 'Zuhause'
];