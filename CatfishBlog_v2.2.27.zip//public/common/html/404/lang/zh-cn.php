<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => '您访问的页面出去玩了!',
    'The page does not exist, please click the link at the bottom of the page to return' => '您访问的页面不存在，请点击页底的链接返回',
    'Access error' => '访问出错',
    'Return to the home page' => '返回首页'
];