<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/30
 */
return [
    'Article list' => '기사 목록',
    'No search found' => '검색 내용을 찾을 수 없습니다',
    'Search' => '검색',
    'Message content must be filled out' => '댓글 작성 내용은 반드시',
    'The e-mail format is incorrect' => '전자 메일 형식이 잘못되었습니다.',
    'secrecy' => '비밀',
    'male' => '남성',
    'female' => '여자',
    'Sign up' => '등록',
    'Log in' => '로그인',
    'User center' => '사용자 중심',
    'Sign out' => '로그 아웃',
    'Related categories' => '관련 카테고리',
    'Articles' => '물품',
    ' seconds ago' => ' 초 전',
    ' minutes ago' => ' 분 전',
    ' hours ago' => ' 시간 전',
    ' days ago' => ' 일 전',
    ' years ago' => ' 년 전'
];